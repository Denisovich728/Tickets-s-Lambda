const express = require('express');
const router = express.Router();
const { Ticket, Event } = require('../models');
const QRCode = require('qrcode');
const { authenticateToken } = require('./auth');
const { v4: uuidv4 } = require('uuid');

// Generate Tickets
router.post('/generate', authenticateToken, async (req, res) => {
    const { eventId, quantity, holderName, seatId } = req.body;
    try {
        const event = await Event.findByPk(eventId);
        if (!event) return res.status(404).json({ error: 'Event not found' });

        const tickets = [];
        // If seatId is provided, force quantity to 1 (or handle multiple seats logic later)
        const qty = seatId ? 1 : quantity;

        for (let i = 0; i < qty; i++) {
            const folio = `${event.type.substring(0, 3).toUpperCase()}-${Date.now()}-${uuidv4().substring(0, 4).toUpperCase()}`;
            const qrData = JSON.stringify({ folio, eventId, seatId }); // Embed seatId in QR if exists

            // Generate QR Image Data URL
            const qrImage = await QRCode.toDataURL(qrData);

            const ticket = await Ticket.create({
                folio,
                qrCodeData: qrData,
                eventId,
                holderName,
                seatId: seatId || null,
                status: 'generated'
            });

            // Attach the generated image for immediate display/download
            ticket.dataValues.qrImage = qrImage;
            tickets.push(ticket);
        }

        res.json(tickets);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Validate/Burn Ticket (Scanner API)
router.post('/validate', authenticateToken, async (req, res) => {
    const { qrData } = req.body;
    try {
        // Parse if it's JSON string, or treat as folio if simple string
        let folio;
        try {
            const parsed = JSON.parse(qrData);
            folio = parsed.folio;
        } catch (e) {
            folio = qrData;
        }

        const ticket = await Ticket.findOne({ where: { folio }, include: Event });
        if (!ticket) return res.status(404).json({ error: 'Ticket not found' });

        if (ticket.status === 'used') {
            return res.status(400).json({ error: 'Ticket already used/burned', ticket });
        }

        if (ticket.status === 'revoked') {
            return res.status(400).json({ error: 'Ticket is revoked', ticket });
        }

        // Burn it
        ticket.status = 'used';
        await ticket.save();

        res.json({ message: 'Access Granted', ticket });

    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

router.get('/event/:id', authenticateToken, async (req, res) => {
    try {
        const tickets = await Ticket.findAll({ where: { eventId: req.params.id } });
        res.json(tickets);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

module.exports = router;
