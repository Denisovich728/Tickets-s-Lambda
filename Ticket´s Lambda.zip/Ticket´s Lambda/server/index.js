const express = require('express');
const cors = require('cors');
const { Sequelize } = require('sequelize');
const dotenv = require('dotenv');

dotenv.config();

const app = express();
const PORT = process.env.PORT || 3001;

// Middleware
app.use(cors());
app.use(express.json());

const { sequelize } = require('./models');
const { router: authRouter } = require('./routes/auth');
const eventRouter = require('./routes/events');
const ticketRouter = require('./routes/tickets');
const staffRouter = require('./routes/staff');

// Test DB Connection
sequelize.authenticate()
  .then(() => console.log('Database connected...'))
  .catch(err => console.log('Error: ' + err));

app.use('/auth', authRouter);
app.use('/events', eventRouter);
app.use('/tickets', ticketRouter);
app.use('/staff', staffRouter);

// Routes placeholder
app.get('/', (req, res) => {
  res.send('API Running');
});

// Start Server
app.listen(PORT, () => {
  console.log(`Server started on port ${PORT}`);
});
