const { Sequelize } = require('sequelize');
const path = require('path');

const sequelize = new Sequelize({
    dialect: 'sqlite',
    storage: path.join(__dirname, '../database.sqlite'),
    logging: false
});

const User = require('./User')(sequelize);
const Event = require('./Event')(sequelize);
const Ticket = require('./Ticket')(sequelize);
const TimeLog = require('./TimeLog')(sequelize);
const Staff = require('./Staff')(sequelize);

const EventStaff = require('./EventStaff')(sequelize);

// Associations

// User (Organizer) -> Events
User.hasMany(Event, { foreignKey: 'organizerId' });
Event.belongsTo(User, { foreignKey: 'organizerId' });

// Event -> Tickets
Event.hasMany(Ticket, { foreignKey: 'eventId' });
Ticket.belongsTo(Event, { foreignKey: 'eventId' });

// Staff -> TimeLogs
User.hasMany(TimeLog, { foreignKey: 'staffId' });
TimeLog.belongsTo(User, { foreignKey: 'staffId' });

// Event -> TimeLogs (Staff working at an event)
Event.hasMany(TimeLog, { foreignKey: 'eventId' });
TimeLog.belongsTo(Event, { foreignKey: 'eventId' });

// Event <-> Staff (Many-to-Many Assignment)
Event.belongsToMany(User, { through: EventStaff, as: 'StaffMembers', foreignKey: 'eventId' });
User.belongsToMany(Event, { through: EventStaff, as: 'AssignedEvents', foreignKey: 'userId' });

module.exports = {
    sequelize,
    User,
    Event,
    Ticket,
    TimeLog,
    EventStaff,
    Staff
};
