import { useState, useEffect } from 'react';
import api from '../api/axios';
import { Users, Plus, QrCode, Trash2, Edit2, CheckCircle, XCircle } from 'lucide-react';
import QRCode from 'qrcode';

export default function StaffProfiles() {
    const [staffList, setStaffList] = useState([]);
    const [loading, setLoading] = useState(false);
    const [showForm, setShowForm] = useState(false);
    const [formData, setFormData] = useState({ name: '', role: 'Mesero' });
    const [qrPreview, setQrPreview] = useState(null);

    useEffect(() => {
        fetchStaff();
    }, []);

    const fetchStaff = async () => {
        setLoading(true);
        try {
            const res = await api.get('/staff');
            setStaffList(res.data);
        } catch (error) {
            console.error("Error fetching staff", error);
        } finally {
            setLoading(false);
        }
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            await api.post('/staff', formData);
            setShowForm(false);
            setFormData({ name: '', role: 'Mesero' });
            fetchStaff();
        } catch (error) {
            alert('Error creating staff');
        }
    };

    const handleDelete = async (id) => {
        if (!window.confirm('¿Eliminar personal?')) return;
        try {
            await api.delete(`/staff/${id}`);
            fetchStaff();
        } catch (error) {
            console.error(error);
        }
    };

    const generateQrPreview = async (staff) => {
        try {
            const url = await QRCode.toDataURL(staff.qrCodeData);
            setQrPreview({ ...staff, qrUrl: url });
        } catch (error) {
            console.error(error);
        }
    };

    return (
        <div className="space-y-8 animate-in fade-in duration-500">
            <header className="border-b border-slate-700 pb-6 flex justify-between items-center">
                <div>
                    <h2 className="text-3xl font-bold text-gray-100 flex items-center">
                        <Users className="w-8 h-8 mr-3 text-indigo-500" />
                        Perfiles de Empleados
                    </h2>
                    <p className="text-slate-400 mt-2">Gestiona el personal y genera sus códigos QR de acceso.</p>
                </div>
                <button
                    onClick={() => setShowForm(!showForm)}
                    className="bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-lg flex items-center transition-colors"
                >
                    <Plus className="w-5 h-5 mr-2" />
                    Nuevo Empleado
                </button>
            </header>

            {/* Form */}
            {showForm && (
                <div className="bg-slate-800 p-6 rounded-xl border border-slate-700 shadow-xl max-w-2xl mx-auto">
                    <h3 className="text-xl font-bold text-white mb-4">Agregar Nuevo Empleado</h3>
                    <form onSubmit={handleSubmit} className="space-y-4">
                        <div>
                            <label className="block text-slate-400 mb-1">Nombre Completo</label>
                            <input
                                type="text"
                                required
                                className="w-full bg-slate-900 border border-slate-700 rounded-lg px-4 py-2 text-white"
                                value={formData.name}
                                onChange={e => setFormData({ ...formData, name: e.target.value })}
                            />
                        </div>
                        <div>
                            <label className="block text-slate-400 mb-1">Rol / Puesto</label>
                            <select
                                className="w-full bg-slate-900 border border-slate-700 rounded-lg px-4 py-2 text-white"
                                value={formData.role}
                                onChange={e => setFormData({ ...formData, role: e.target.value })}
                            >
                                <option value="Mesero">Mesero</option>
                                <option value="Seguridad">Seguridad</option>
                                <option value="Bartender">Bartender</option>
                                <option value="Staff General">Staff General</option>
                                <option value="DJ">DJ / Entretenimiento</option>
                            </select>
                        </div>
                        <div className="flex justify-end pt-4">
                            <button type="submit" className="bg-emerald-600 hover:bg-emerald-700 text-white px-6 py-2 rounded-lg">
                                Guardar
                            </button>
                        </div>
                    </form>
                </div>
            )}

            {/* List */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {staffList.map(staff => (
                    <div key={staff.id} className="bg-slate-800 rounded-xl border border-slate-700 p-6 shadow-lg hover:shadow-indigo-500/10 transition-all group">
                        <div className="flex justify-between items-start mb-4">
                            <div className="bg-indigo-900/50 p-3 rounded-full text-indigo-400 font-bold text-xl">
                                {staff.name.charAt(0)}
                            </div>
                            <div className="flex space-x-2 opacity-0 group-hover:opacity-100 transition-opacity">
                                <button onClick={() => handleDelete(staff.id)} className="text-red-400 hover:text-red-300 p-1">
                                    <Trash2 className="w-5 h-5" />
                                </button>
                            </div>
                        </div>
                        <h3 className="text-xl font-bold text-white">{staff.name}</h3>
                        <p className="text-indigo-400 font-medium mb-4">{staff.role}</p>

                        <div className="border-t border-slate-700 pt-4 flex justify-between items-center">
                            <span className={staff.isActive ? "text-emerald-400 text-xs flex items-center" : "text-red-400 text-xs flex items-center"}>
                                {staff.isActive ? <CheckCircle className="w-3 h-3 mr-1" /> : <XCircle className="w-3 h-3 mr-1" />}
                                {staff.isActive ? "Activo" : "Inactivo"}
                            </span>
                            <button
                                onClick={() => generateQrPreview(staff)}
                                className="text-slate-300 hover:text-white flex items-center text-sm bg-slate-700 px-3 py-1.5 rounded-lg hover:bg-slate-600 transition-colors"
                            >
                                <QrCode className="w-4 h-4 mr-2" />
                                Ver QR
                            </button>
                        </div>
                    </div>
                ))}
            </div>

            {/* QR Modal */}
            {qrPreview && (
                <div className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center p-4" onClick={() => setQrPreview(null)}>
                    <div className="bg-white p-8 rounded-2xl max-w-sm w-full text-center" onClick={e => e.stopPropagation()}>
                        <h3 className="text-2xl font-bold text-slate-900 mb-2">{qrPreview.name}</h3>
                        <p className="text-slate-500 mb-6 uppercase tracking-widest text-xs font-bold">{qrPreview.role}</p>
                        <div className="bg-slate-100 p-4 rounded-xl inline-block mb-6">
                            <img src={qrPreview.qrUrl} alt="QR" className="w-48 h-48 mix-blend-multiply" />
                        </div>
                        <p className="text-xs text-slate-400 mb-6">Escanea este código para Registrar Entrada/Salida</p>
                        <button
                            onClick={() => setQrPreview(null)}
                            className="bg-slate-900 text-white w-full py-3 rounded-xl font-bold hover:bg-slate-800"
                        >
                            Cerrar
                        </button>
                    </div>
                </div>
            )}
        </div>
    );
}
