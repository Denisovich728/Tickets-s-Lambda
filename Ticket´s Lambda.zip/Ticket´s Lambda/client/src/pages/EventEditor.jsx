import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import api from '../api/axios';
import LayoutEditor from '../components/LayoutEditor';

export default function EventEditor() {
    const { id } = useParams();
    const navigate = useNavigate();
    const [event, setEvent] = useState({
        name: '',
        date: '',
        type: 'General',
        capacity: 100,
        accessRules: null // Using this field to store layout for now, or create separate field
        // Note: In DB accessRules is JSON. We can use it for layout or create a new column. 
        // For prototype, let's use a specific field in the model if possible or just pack it here.
        // Actually, the prompt asked for "access rules" AND "layout". 
        // I will overload accessRules for now or just assume backend accepts a `layout` field if I add it.
        // Let's stick to the model: Event has `accessRules` (JSON). I can put `{ layout: ... }` inside accessRules.
    });
    const [layoutData, setLayoutData] = useState(null);

    useEffect(() => {
        if (id) {
            api.get(`/events/${id}`).then(res => {
                const data = res.data;
                setEvent({
                    name: data.name,
                    date: data.date.split('T')[0], // Formatting for input type=date
                    type: data.type,
                    capacity: data.capacity,
                });
                if (data.accessRules && data.accessRules.layout) {
                    setLayoutData(data.accessRules.layout);
                }
            });
        }
    }, [id]);

    const handleSubmit = async (e) => {
        e.preventDefault();
        const payload = {
            ...event,
            accessRules: { layout: layoutData } // Saving layout inside accessRules JSON
        };

        try {
            if (id) {
                await api.put(`/events/${id}`, payload);
            } else {
                await api.post('/events', payload);
            }
            navigate('/');
        } catch (error) {
            console.error("Error saving event", error);
        }
    };

    return (
        <div className="bg-white shadow sm:rounded-lg p-6">
            <h2 className="text-2xl font-bold mb-6">{id ? 'Editar Evento' : 'Nuevo Evento'}</h2>
            <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid grid-cols-1 gap-6 sm:grid-cols-2">
                    <div>
                        <label className="block text-sm font-medium text-gray-700">Nombre del Evento</label>
                        <input
                            type="text"
                            required
                            className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                            value={event.name}
                            onChange={e => setEvent({ ...event, name: e.target.value })}
                        />
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-gray-700">Fecha</label>
                        <input
                            type="date"
                            required
                            className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                            value={event.date}
                            onChange={e => setEvent({ ...event, date: e.target.value })}
                        />
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-gray-700">Tipo de Evento</label>
                        <select
                            className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                            value={event.type}
                            onChange={e => setEvent({ ...event, type: e.target.value })}
                        >
                            <option value="General">General</option>
                            <option value="Boda">Boda</option>
                            <option value="Concierto">Concierto</option>
                            <option value="Convivio">Convivio</option>
                            <option value="Antro">Antro</option>
                        </select>
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-gray-700">Capacidad</label>
                        <input
                            type="number"
                            required
                            className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                            value={event.capacity}
                            onChange={e => setEvent({ ...event, capacity: parseInt(e.target.value) })}
                        />
                    </div>
                </div>

                <div className="border-t border-gray-200 pt-6">
                    <h3 className="text-lg font-medium text-gray-900 mb-4">Mapa de Asientos</h3>
                    <LayoutEditor initialData={layoutData} onSave={data => setLayoutData(JSON.parse(data))} />
                    <p className="mt-2 text-sm text-gray-500">
                        Recuerda dar click en "Guardar Diseño" dentro del editor antes de guardar el evento.
                    </p>
                </div>

                <div className="flex justify-end">
                    <button
                        type="button"
                        onClick={() => navigate('/')}
                        className="bg-white py-2 px-4 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 hover:bg-gray-50 mr-3"
                    >
                        Cancelar
                    </button>
                    <button
                        type="submit"
                        className="inline-flex justify-center py-2 px-4 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
                    >
                        Guardar Evento
                    </button>
                </div>
            </form>
        </div>
    );
}
