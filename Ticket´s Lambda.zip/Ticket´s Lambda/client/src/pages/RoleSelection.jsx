import { useNavigate } from 'react-router-dom';
import { ShieldCheck, ScanLine } from 'lucide-react';


export default function RoleSelection() {
    const navigate = useNavigate();

    return (
        <div className="min-h-screen bg-slate-900 flex flex-col items-center justify-center p-4">
            <div className="text-center mb-12">
                <h1 className="text-4xl font-bold text-white mb-2 tracking-tight">Ticket's Lambda</h1>
                <p className="text-slate-400">Selecciona tu perfil para ingresar</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-4xl w-full">
                {/* Organizador Card */}
                <button
                    onClick={() => navigate('/login?role=admin')}
                    className="group bg-slate-800 hover:bg-indigo-900/20 border border-slate-700 hover:border-indigo-500 p-8 rounded-3xl transition-all duration-300 flex flex-col items-center text-center shadow-2xl hover:shadow-indigo-500/10"
                >
                    <div className="bg-slate-700 group-hover:bg-indigo-600 p-6 rounded-2xl mb-6 transition-colors duration-300">
                        <ShieldCheck className="w-12 h-12 text-white" />
                    </div>
                    <h2 className="text-2xl font-bold text-white mb-2">Soy Organizador</h2>
                    <p className="text-slate-400 group-hover:text-slate-300">
                        Gestionar eventos, diseñar mapas y crear tickets.
                    </p>
                </button>

                {/* Portero/Staff Card */}
                <button
                    onClick={() => navigate('/login?role=staff')}
                    className="group bg-slate-800 hover:bg-emerald-900/20 border border-slate-700 hover:border-emerald-500 p-8 rounded-3xl transition-all duration-300 flex flex-col items-center text-center shadow-2xl hover:shadow-emerald-500/10"
                >
                    <div className="bg-slate-700 group-hover:bg-emerald-600 p-6 rounded-2xl mb-6 transition-colors duration-300">
                        <ScanLine className="w-12 h-12 text-white" />
                    </div>
                    <h2 className="text-2xl font-bold text-white mb-2">Soy Portero / Staff</h2>
                    <p className="text-slate-400 group-hover:text-slate-300">
                        Escanear tickets, validar accesos y registrar horas.
                    </p>
                </button>
            </div>

            <p className="mt-12 text-slate-600 text-sm">© 2026 Ticket's Lambda System</p>
        </div>
    );
}
