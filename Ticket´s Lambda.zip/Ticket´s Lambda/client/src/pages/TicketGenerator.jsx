import { useState, useEffect, useRef } from 'react';
import { useParams } from 'react-router-dom';
import api from '../api/axios';
import html2canvas from 'html2canvas';
import JSZip from 'jszip';
import { saveAs } from 'file-saver';
import { Download, Users, Ticket as TicketIcon, Loader2 } from 'lucide-react';
import QRCode from 'qrcode';

export default function TicketGenerator() {
    const { id } = useParams();
    const [event, setEvent] = useState(null);
    const [tickets, setTickets] = useState([]);
    const [quantity, setQuantity] = useState(1);
    const [holderName, setHolderName] = useState('');
    const [isGenerating, setIsGenerating] = useState(false);

    // Config for consolidated tickets
    const [consolidated, setConsolidated] = useState(false); // If true, 1 ticket for N people

    // New: Seat Selection
    const [availableSeats, setAvailableSeats] = useState([]);
    const [selectedSeat, setSelectedSeat] = useState('');

    useEffect(() => {
        api.get(`/events/${id}`).then(res => {
            setEvent(res.data);
            if (res.data.layout) {
                try {
                    const canvasData = JSON.parse(res.data.layout);
                    // Extract seats (objects with seatLabel)
                    const seats = [];
                    // Handle recursive helper if groups
                    const extractSeats = (objs) => {
                        objs.forEach(obj => {
                            if (obj.seatLabel) seats.push(obj.seatLabel);
                            if (obj.objects) extractSeats(obj.objects); // In case of Groups within Groups
                            // Note: Fabric structure for Group: obj.objects
                        });
                    };
                    if (canvasData.objects) extractSeats(canvasData.objects);
                    setAvailableSeats(seats.sort());
                } catch (e) {
                    console.error("Error parsing layout", e);
                }
            }
        });
    }, [id]);

    const handleGenerate = async () => {
        setIsGenerating(true);
        try {
            const res = await api.post('/tickets/generate', {
                eventId: id,
                quantity: selectedSeat ? 1 : (consolidated ? 1 : quantity),
                holderName: holderName || 'Portador',
                seatId: selectedSeat || null
            });

            // If consolidated, visually append the pax count for the UI (custom logic)
            // If seat selected, assume pax = 1 unless logic changes
            const newTickets = res.data.map(t => ({
                ...t,
                pax: selectedSeat ? 1 : (consolidated ? quantity : 1)
            }));

            // Generate QR data URLs locally if not provided by backend image
            const ticketsWithQRs = await Promise.all(newTickets.map(async (t) => {
                if (!t.qrCodeData) {
                    const qr = await QRCode.toDataURL(t.folio);
                    return { ...t, qrCodeData: qr };
                }
                return t;
            }));

            setTickets([...tickets, ...ticketsWithQRs]);

            // Clear selection if needed
            if (selectedSeat) setSelectedSeat('');

        } catch (error) {
            console.error("Error generating tickets", error);
        } finally {
            setIsGenerating(false);
        }
    };

    // ... downloadZip ...

    if (!event) return <div className="p-8 text-center text-slate-400"><Loader2 className="w-8 h-8 animate-spin mx-auto" /> Cargo evento...</div>;

    return (
        <div className="space-y-8 animate-in fade-in duration-500">
            <header className="border-b border-slate-700 pb-6">
                <h2 className="text-3xl font-bold text-gray-100 flex items-center">
                    <TicketIcon className="w-8 h-8 mr-3 text-indigo-500" />
                    Generador de Tickets
                </h2>
                <p className="text-slate-400 mt-2 text-lg">Evento: <span className="text-white font-medium">{event.name}</span></p>
            </header>

            <div className="bg-slate-800 p-6 rounded-2xl shadow-xl border border-slate-700/50">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 items-end">

                    {/* Quantity or Seat Selection */}
                    {availableSeats.length > 0 ? (
                        <div>
                            <label className="block text-sm font-medium text-slate-400 mb-1">Asignar Asiento</label>
                            <select
                                className="w-full bg-slate-900 border border-slate-700 rounded-xl px-4 py-2 text-white focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                                value={selectedSeat}
                                onChange={e => {
                                    setSelectedSeat(e.target.value);
                                    if (e.target.value) setQuantity(1); // Force qty 1 if seat selected
                                }}
                            >
                                <option value="">-- Sin Asiento / General --</option>
                                {availableSeats.map(seat => (
                                    <option key={seat} value={seat}>{seat}</option>
                                ))}
                            </select>
                        </div>
                    ) : (
                        <div>
                            <label className="block text-sm font-medium text-slate-400 mb-1">Cantidad de Personas</label>
                            <input
                                type="number"
                                min="1"
                                className="w-full bg-slate-900 border border-slate-700 rounded-xl px-4 py-2 text-white focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                                value={quantity}
                                onChange={e => setQuantity(e.target.value)}
                            />
                        </div>
                    )}

                    <div className="lg:col-span-2">
                        <label className="block text-sm font-medium text-slate-400 mb-1">Nombre del Portador / Familia</label>
                        <input
                            type="text"
                            className="w-full bg-slate-900 border border-slate-700 rounded-xl px-4 py-2 text-white focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                            value={holderName}
                            onChange={e => setHolderName(e.target.value)}
                            placeholder="Ej. Familia Pérez o Juanito Banana"
                        />
                    </div>

                    <div className="flex items-center space-x-2 pb-3">
                        {!selectedSeat && (
                            <>
                                <input
                                    type="checkbox"
                                    id="consolidated"
                                    checked={consolidated}
                                    onChange={e => setConsolidated(e.target.checked)}
                                    className="w-5 h-5 text-indigo-600 rounded focus:ring-indigo-500 bg-slate-900 border-slate-700"
                                />
                                <label htmlFor="consolidated" className="text-slate-300 text-sm cursor-pointer select-none">
                                    Generar 1 solo QR (Grupo)
                                </label>
                            </>
                        )}
                    </div>
                </div>

                <div className="mt-6 flex flex-wrap gap-4">
                    <button
                        onClick={handleGenerate}
                        disabled={isGenerating}
                        className="bg-indigo-600 hover:bg-indigo-700 text-white px-6 py-2.5 rounded-xl flex items-center shadow-lg shadow-indigo-500/20 transition-all font-medium disabled:opacity-50"
                    >
                        {isGenerating ? <Loader2 className="w-5 h-5 animate-spin mr-2" /> : <TicketIcon className="w-5 h-5 mr-2" />}
                        Generar Tickets
                    </button>

                    {tickets.length > 0 && (
                        <>
                            <button
                                onClick={() => downloadZip('desktop')}
                                className="bg-emerald-600 hover:bg-emerald-700 text-white px-6 py-2.5 rounded-xl flex items-center shadow-lg shadow-emerald-500/20 transition-all font-medium"
                            >
                                <Download className="w-5 h-5 mr-2" /> Imprimir (Tira)
                            </button>
                            <button
                                onClick={() => downloadZip('mobile')}
                                className="bg-sky-600 hover:bg-sky-700 text-white px-6 py-2.5 rounded-xl flex items-center shadow-lg shadow-sky-500/20 transition-all font-medium"
                            >
                                <Smartphone className="w-5 h-5 mr-2" /> Formato Celular
                            </button>
                        </>
                    )}
                </div>
            </div>

            {/* Desktop Preview List (Visible) */}
            <div className="flex flex-col space-y-8">
                {tickets.map((ticket, idx) => (
                    <div key={idx} className="w-full flex justify-center">
                        {/* Desktop Ticket: 9:2 Aspect Ratio */}
                        <div
                            id={`ticket-${ticket.folio}`}
                            className="bg-white text-slate-900 w-full max-w-5xl aspect-[9/2.5] flex overflow-hidden shadow-xl rounded-none border border-slate-300 relative print:shadow-none"
                            style={{ minHeight: '220px' }}
                        >
                            {/* Left Stub: Event Info */}
                            <div className="w-3/4 bg-slate-100 flex flex-row relative">
                                {/* Event Image / Gradient Placeholder */}
                                <div className="w-1/4 h-full bg-slate-900 relative overflow-hidden flex items-center justify-center">
                                    <div className="absolute inset-0 bg-gradient-to-br from-indigo-900 to-slate-900"></div>
                                    <span className="relative text-white/20 font-bold text-6xl -rotate-90 tracking-widest uppercase truncate">{event.type || 'EVENT'}</span>
                                    <div className="absolute -left-6 top-1/2 w-12 h-12 bg-white rounded-full"></div>
                                </div>

                                {/* Main Event Details */}
                                <div className="flex-1 p-6 flex flex-col justify-between relative border-r-2 border-dashed border-slate-300">
                                    <div className="absolute -top-3 right-0 transform translate-x-1/2 w-6 h-6 bg-white rounded-full border border-slate-300 z-10"></div>
                                    <div>
                                        <h1 className="text-3xl font-black uppercase text-slate-900 leading-none mb-2">{event.name}</h1>
                                        <p className="text-xl text-indigo-600 font-medium">{new Date(event.date).toLocaleDateString(undefined, { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}</p>
                                        <p className="text-slate-500 mt-1">{event.location || 'Ubicación pendiente'}</p>
                                    </div>
                                    <div className="flex justify-between items-end">
                                        <div>
                                            <p className="text-xs text-slate-400 uppercase tracking-widest">Portador</p>
                                            <p className="font-bold text-xl">{ticket.holderName}</p>
                                            {ticket.seatId && (
                                                <p className="text-indigo-600 font-bold text-lg mt-1">Asiento: {ticket.seatId}</p>
                                            )}
                                            {ticket.pax > 1 && (
                                                <span className="inline-block mt-1 bg-black text-white text-xs px-2 py-0.5 rounded uppercase font-bold">
                                                    Válido por {ticket.pax} personas
                                                </span>
                                            )}
                                        </div>
                                        <div className="text-right">
                                            <p className="text-xs text-slate-400 uppercase tracking-widest">Hora</p>
                                            <p className="font-bold text-xl">{new Date(event.date).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</p>
                                        </div>
                                    </div>
                                    <div className="absolute -bottom-3 right-0 transform translate-x-1/2 w-6 h-6 bg-white rounded-full border border-slate-300 z-10"></div>
                                </div>
                            </div>

                            {/* Right Stub: QR & Validation */}
                            <div className="w-1/4 bg-white p-4 flex flex-col items-center justify-center relative border-l-2 border-dashed border-slate-300">
                                <img src={ticket.qrDisplay || ticket.qrImage || ticket.qrCodeData} alt="QR" className="w-32 h-32 object-contain mix-blend-multiply" />
                                <div className="mt-2 text-center">
                                    <p className="font-mono font-bold text-sm tracking-widest text-slate-500">{ticket.folio.split('-').pop()}</p>
                                    <span className={ticket.status === 'used' ? 'text-red-500 font-bold text-xs' : 'text-emerald-600 font-bold text-xs'}>
                                        {ticket.status === 'used' ? 'USADO' : 'VALIDO'}
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>
                ))}
            </div>

            {/* Mobile Render List (Hidden, OFF-SCREEN but robust) */}
            {/* We place it absolute off-screen so html2canvas can still capture it */}
            <div className="absolute top-0 -left-[9999px]">
                {tickets.map((ticket, idx) => (
                    <div
                        key={`mobile-${idx}`}
                        id={`mobile-ticket-${ticket.folio}`}
                        className="bg-slate-900 text-white relative overflow-hidden flex flex-col items-center text-center p-8"
                        style={{ width: '450px', height: '800px' }} // Approx 9:16 Ratio
                    >
                        {/* Background Accents */}
                        <div className="absolute top-0 left-0 w-full h-2 bg-gradient-to-r from-indigo-500 via-purple-500 to-pink-500"></div>
                        <div className="absolute -left-16 -top-16 w-32 h-32 bg-indigo-500/20 rounded-full blur-3xl"></div>
                        <div className="absolute -right-16 bottom-16 w-40 h-40 bg-purple-500/20 rounded-full blur-3xl"></div>

                        {/* Mobile Wrapper */}
                        <div className="mt-12 mb-auto w-full px-8 z-10 text-left">
                            <h2 className="text-4xl font-black uppercase tracking-tight mb-2 leading-none text-white">{event.name}</h2>
                            <p className="text-indigo-400 font-bold text-xl mb-4">{new Date(event.date).toLocaleDateString(undefined, { weekday: 'long', day: 'numeric', month: 'long' })}</p>

                            <div className="space-y-4 border-l-4 border-indigo-500 pl-4 my-8">
                                <div>
                                    <p className="text-slate-400 text-xs uppercase tracking-widest">Hora</p>
                                    <p className="text-white text-lg font-semibold">{new Date(event.date).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</p>
                                </div>
                                <div>
                                    <p className="text-slate-400 text-xs uppercase tracking-widest">Ubicación</p>
                                    <p className="text-white text-lg font-semibold">{event.location || 'Ubicación pendiente'}</p>
                                </div>
                                <div>
                                    <p className="text-slate-400 text-xs uppercase tracking-widest">Portador</p>
                                    <p className="text-white text-2xl font-bold">{ticket.holderName}</p>
                                    {ticket.pax > 1 && (
                                        <span className="inline-block mt-1 bg-indigo-600 text-white text-xs px-2 py-0.5 rounded uppercase font-bold">
                                            Acceso: {ticket.pax} pax
                                        </span>
                                    )}
                                </div>
                                <div>
                                    <p className="text-slate-400 text-xs uppercase tracking-widest">Folio</p>
                                    <p className="font-mono text-emerald-400 text-lg tracking-wider">{ticket.folio}</p>
                                </div>
                            </div>
                        </div>

                        {/* Divider */}
                        <div className="w-full border-b-2 border-dashed border-slate-700 my-4 relative">
                            <div className="absolute -left-10 -top-3 w-6 h-6 bg-slate-900 rounded-full"></div>
                            <div className="absolute -right-10 -top-3 w-6 h-6 bg-slate-900 rounded-full"></div>
                        </div>

                        {/* QR at Bottom */}
                        <div className="mb-12 z-10 bg-white p-4 rounded-2xl shadow-2xl">
                            <img src={ticket.qrDisplay || ticket.qrImage || ticket.qrCodeData} alt="QR" className="w-64 h-64 object-contain mix-blend-multiply" style={{ imageRendering: 'pixelated' }} />
                            <p className="text-slate-900 text-center font-bold text-sm mt-2 uppercase tracking-widest">Escanear para acceder</p>
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
}
