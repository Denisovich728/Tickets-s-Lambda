import { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { Link, useLocation } from 'react-router-dom';
import {
    LogOut, Home, PlusCircle, ScanLine,
    Ticket as TicketIcon, Users, Menu, X, Database
} from 'lucide-react';
import { cn } from '../utils/cn';

export default function Sidebar() {
    const { user, logout } = useAuth();
    const location = useLocation();
    const [isOpen, setIsOpen] = useState(false); // Mobile toggle
    const [isCollapsed, setIsCollapsed] = useState(false); // Desktop toggle

    if (!user) return null;

    const navItems = [
        { path: '/dashboard', label: 'Dashboard', icon: Home, roles: ['admin', 'client', 'staff'] },
        { path: '/events/new', label: 'Nuevo Evento', icon: PlusCircle, roles: ['admin', 'client'] },
        { path: '/users', label: 'Usuarios', icon: Users, roles: ['admin'] },
        { path: '/staff-profiles', label: 'Personal', icon: Users, roles: ['admin'] },
        { path: '/scanner', label: 'Escáner', icon: ScanLine, roles: ['admin', 'client', 'staff'] },
        { path: '/admin/db', label: 'Base de Datos', icon: Database, roles: ['admin'] },
    ];

    const toggleOpen = () => setIsOpen(!isOpen);

    return (
        <>
            {/* Mobile Header */}
            <div className="md:hidden bg-slate-800 text-white p-4 flex justify-between items-center shadow-md">
                <span className="font-bold text-xl">Ticket's Lambda</span>
                <button onClick={toggleOpen}>
                    {isOpen ? <X /> : <Menu />}
                </button>
            </div>

            {/* Sidebar Container */}
            <div className={cn(
                "fixed inset-y-0 left-0 z-50 bg-slate-900 text-gray-100 transition-all duration-300 ease-in-out transform md:translate-x-0 shadow-xl flex flex-col",
                isOpen ? "translate-x-0 w-64" : "-translate-x-full md:w-64",
                isCollapsed && "md:w-20"
            )}>
                {/* Desktop Header / Collapse Toggle */}
                <div className="hidden md:flex items-center justify-between p-4 border-b border-slate-700 h-16">
                    {!isCollapsed && <span className="font-bold text-xl tracking-wider">Lambda</span>}
                    <button onClick={() => setIsCollapsed(!isCollapsed)} className="p-1 hover:bg-slate-700 rounded-lg">
                        <Menu size={20} />
                    </button>
                </div>

                {/* User Info */}
                <div className={cn("p-4 border-b border-slate-700 flex items-center gap-3", isCollapsed && "justify-center")}>
                    <div className="w-10 h-10 rounded-full bg-indigo-600 flex items-center justify-center font-bold shadow-lg shadow-indigo-500/30">
                        {user.username.charAt(0).toUpperCase()}
                    </div>
                    {!isCollapsed && (
                        <div className="overflow-hidden">
                            <p className="font-semibold truncate">{user.username}</p>
                            <p className="text-xs text-slate-400 capitalize">{user.role}</p>
                        </div>
                    )}
                </div>

                {/* Navigation Links */}
                <nav className="flex-1 p-4 space-y-6 overflow-y-auto">
                    {navItems.filter(item => {
                        // Default to no access if role undefined
                        const userRole = (user.role || '').toLowerCase();
                        return item.roles.includes(userRole);
                    }).map((item) => {
                        const isActive = location.pathname === item.path;
                        return (
                            <Link
                                key={item.path}
                                to={item.path}
                                onClick={() => setIsOpen(false)}
                                className={cn(
                                    "flex items-center gap-3 p-3 rounded-xl transition-all duration-300 group relative border-2",
                                    isActive
                                        ? "bg-slate-800 text-white border-indigo-500/50 shadow-lg shadow-indigo-500/20"
                                        : "border-transparent text-slate-400 hover:bg-[#C0C0C0] hover:text-black hover:border-[#00FFFF] hover:shadow-[0_0_15px_#00FFFF] hover:font-bold"
                                )}
                            >
                                <item.icon className={cn("w-6 h-6 shrink-0 transition-colors",
                                    isActive ? "text-indigo-400" : "group-hover:text-black"
                                )} />
                                {!isCollapsed && <span className="font-bold tracking-wide">{item.label}</span>}

                                {/* Tooltip for collapsed mode */}
                                {isCollapsed && (
                                    <div className="absolute left-full ml-4 px-2 py-1 bg-slate-800 text-white text-sm rounded opacity-0 group-hover:opacity-100 whitespace-nowrap z-50 shadow-xl border border-slate-600">
                                        {item.label}
                                    </div>
                                )}
                            </Link>
                        );
                    })}
                </nav>

                {/* Footer / Logout */}
                <div className="p-4 border-t border-slate-700">
                    <button
                        onClick={logout}
                        className={cn(
                            "flex items-center gap-3 w-full p-3 rounded-xl hover:bg-red-500/10 text-red-400 hover:text-red-300 transition-colors",
                            isCollapsed && "justify-center"
                        )}
                    >
                        <LogOut className="w-6 h-6 shrink-0" />
                        {!isCollapsed && <span className="font-medium">Cerrar Sesión</span>}
                    </button>
                </div>
            </div>

            {/* Mobile Overlay */}
            {isOpen && (
                <div
                    className="fixed inset-0 bg-black/50 z-40 md:hidden"
                    onClick={() => setIsOpen(false)}
                />
            )}
        </>
    );
}
