import { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import api from '../api/axios';
import { UserPlus, Clock, CheckCircle, AlertCircle } from 'lucide-react';

export default function StaffManager() {
    const { id } = useParams();
    const [staffList, setStaffList] = useState([]);
    const [availableStaff, setAvailableStaff] = useState([]);
    const [selectedStaff, setSelectedStaff] = useState('');
    const [role, setRole] = useState('Staff');
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        fetchData();
    }, [id]);

    const fetchData = async () => {
        setLoading(true);
        try {
            const [rosterRes, availableRes] = await Promise.all([
                api.get(`/staff/event/${id}`),
                api.get('/staff/available')
            ]);
            setStaffList(rosterRes.data);
            setAvailableStaff(availableRes.data);
        } catch (error) {
            console.error(error);
        } finally {
            setLoading(false);
        }
    };

    const handleAssign = async (e) => {
        e.preventDefault();
        try {
            await api.post('/staff/assign', {
                eventId: id,
                userId: selectedStaff,
                role
            });
            fetchData(); // Refresh list
            setSelectedStaff('');
        } catch (error) {
            alert('Error assigning staff');
        }
    };

    const getStatusColor = (status) => {
        switch (status) {
            case 'Working': return 'bg-green-100 text-green-800 border-green-200';
            case 'Finished': return 'bg-gray-100 text-gray-800 border-gray-200';
            default: return 'bg-yellow-100 text-yellow-800 border-yellow-200';
        }
    };

    return (
        <div className="space-y-6">
            <div className="bg-white shadow sm:rounded-lg p-6">
                <h3 className="text-lg font-medium leading-6 text-gray-900 mb-4">Asignar Personal</h3>
                <form onSubmit={handleAssign} className="flex gap-4 items-end">
                    <div>
                        <label className="block text-sm font-medium text-gray-700">Empleado</label>
                        <select
                            className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm rounded-md"
                            value={selectedStaff}
                            onChange={e => setSelectedStaff(e.target.value)}
                            required
                        >
                            <option value="">Seleccionar...</option>
                            {availableStaff.map(s => (
                                <option key={s.id} value={s.id}>{s.username}</option>
                            ))}
                        </select>
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-gray-700">Rol en Evento</label>
                        <input
                            type="text"
                            className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                            value={role}
                            onChange={e => setRole(e.target.value)}
                        />
                    </div>
                    <button type="submit" className="bg-indigo-600 text-white px-4 py-2 rounded-md hover:bg-indigo-700 flex items-center">
                        <UserPlus className="w-4 h-4 mr-2" /> Asignar
                    </button>
                </form>
            </div>

            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
                {staffList.map((staff) => (
                    <div key={staff.id} className={`relative rounded-lg border p-6 shadow-sm flex flex-col ${getStatusColor(staff.status)}`}>
                        <div className="flex-1">
                            <h3 className="text-lg font-semibold">{staff.username}</h3>
                            <p className="text-sm opacity-75">{staff.role}</p>

                            <div className="mt-4 space-y-2 text-sm">
                                <div className="flex justify-between">
                                    <span>Estado:</span>
                                    <span className="font-bold">{staff.status === 'Working' ? 'En Turno' : staff.status === 'Finished' ? 'Finalizado' : 'Pendiente'}</span>
                                </div>
                                {staff.checkIn && (
                                    <div className="flex justify-between items-center">
                                        <div className="flex items-center"><CheckCircle className="w-3 h-3 mr-1" /> Entrada:</div>
                                        <span>{new Date(staff.checkIn).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                                    </div>
                                )}
                                {staff.checkOut && (
                                    <div className="flex justify-between items-center">
                                        <div className="flex items-center"><Clock className="w-3 h-3 mr-1" /> Salida:</div>
                                        <span>{new Date(staff.checkOut).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                                    </div>
                                )}
                            </div>
                        </div>
                    </div>
                ))}

                {staffList.length === 0 && !loading && (
                    <div className="col-span-full text-center text-gray-500 py-8">
                        No hay personal asignado a este evento aún.
                    </div>
                )}
            </div>
        </div>
    );
}
